#include "WebrtcSetSessionDescriptionObserver.h"

WebrtcSetSessionDescriptionObserver::WebrtcSetSessionDescriptionObserver(QObject* parent)
    : QObject{ parent }
{

}